﻿
namespace HouseDoor
{
    partial class imoveis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_imovel = new System.Windows.Forms.DataGridView();
            this.txt_buscar_imovel = new System.Windows.Forms.Button();
            this.txt_logradouro = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_imovel)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_imovel
            // 
            this.dgv_imovel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_imovel.Location = new System.Drawing.Point(408, 26);
            this.dgv_imovel.Name = "dgv_imovel";
            this.dgv_imovel.RowTemplate.Height = 25;
            this.dgv_imovel.Size = new System.Drawing.Size(672, 248);
            this.dgv_imovel.TabIndex = 0;
            // 
            // txt_buscar_imovel
            // 
            this.txt_buscar_imovel.Location = new System.Drawing.Point(466, 336);
            this.txt_buscar_imovel.Name = "txt_buscar_imovel";
            this.txt_buscar_imovel.Size = new System.Drawing.Size(167, 63);
            this.txt_buscar_imovel.TabIndex = 1;
            this.txt_buscar_imovel.Text = "Buscar Imovel";
            this.txt_buscar_imovel.UseVisualStyleBackColor = true;
            this.txt_buscar_imovel.Click += new System.EventHandler(this.txt_buscar_imovel_Click);
            // 
            // txt_logradouro
            // 
            this.txt_logradouro.Location = new System.Drawing.Point(125, 26);
            this.txt_logradouro.Name = "txt_logradouro";
            this.txt_logradouro.Size = new System.Drawing.Size(263, 23);
            this.txt_logradouro.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Logradouro";
            // 
            // imoveis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 480);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_logradouro);
            this.Controls.Add(this.txt_buscar_imovel);
            this.Controls.Add(this.dgv_imovel);
            this.Name = "imoveis";
            this.Text = "imoveis";
            this.Load += new System.EventHandler(this.imoveis_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_imovel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_imovel;
        private System.Windows.Forms.Button txt_buscar_imovel;
        private System.Windows.Forms.TextBox txt_logradouro;
        private System.Windows.Forms.Label label1;
    }
}