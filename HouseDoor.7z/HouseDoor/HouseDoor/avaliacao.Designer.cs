﻿
namespace HouseDoor
{
    partial class avaliacao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txt_id_imovel = new System.Windows.Forms.TextBox();
            this.txt_id_user = new System.Windows.Forms.TextBox();
            this.txt_tempo_contrato = new System.Windows.Forms.TextBox();
            this.txt_motivo = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.txt_avaliacao = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cb_recomenda = new System.Windows.Forms.ComboBox();
            this.btn_cadastrar_avaliacao = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_id_imovel
            // 
            this.txt_id_imovel.Location = new System.Drawing.Point(177, 63);
            this.txt_id_imovel.Name = "txt_id_imovel";
            this.txt_id_imovel.Size = new System.Drawing.Size(193, 23);
            this.txt_id_imovel.TabIndex = 0;
            // 
            // txt_id_user
            // 
            this.txt_id_user.Location = new System.Drawing.Point(177, 105);
            this.txt_id_user.Name = "txt_id_user";
            this.txt_id_user.Size = new System.Drawing.Size(193, 23);
            this.txt_id_user.TabIndex = 1;
            // 
            // txt_tempo_contrato
            // 
            this.txt_tempo_contrato.Location = new System.Drawing.Point(177, 148);
            this.txt_tempo_contrato.Name = "txt_tempo_contrato";
            this.txt_tempo_contrato.Size = new System.Drawing.Size(193, 23);
            this.txt_tempo_contrato.TabIndex = 2;
            // 
            // txt_motivo
            // 
            this.txt_motivo.Location = new System.Drawing.Point(177, 225);
            this.txt_motivo.Multiline = true;
            this.txt_motivo.Name = "txt_motivo";
            this.txt_motivo.Size = new System.Drawing.Size(193, 134);
            this.txt_motivo.TabIndex = 3;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // txt_avaliacao
            // 
            this.txt_avaliacao.Location = new System.Drawing.Point(177, 196);
            this.txt_avaliacao.Name = "txt_avaliacao";
            this.txt_avaliacao.Size = new System.Drawing.Size(193, 23);
            this.txt_avaliacao.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(119, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "id imovel";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(119, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "id_user";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(69, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 15);
            this.label3.TabIndex = 9;
            this.label3.Text = "tempo de contrato";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(119, 273);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 15);
            this.label4.TabIndex = 10;
            this.label4.Text = "motivos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(113, 204);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 15);
            this.label5.TabIndex = 11;
            this.label5.Text = "avaliacao";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(60, 399);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 15);
            this.label6.TabIndex = 12;
            this.label6.Text = "recomenda imovel?";
            // 
            // cb_recomenda
            // 
            this.cb_recomenda.FormattingEnabled = true;
            this.cb_recomenda.Location = new System.Drawing.Point(195, 399);
            this.cb_recomenda.Name = "cb_recomenda";
            this.cb_recomenda.Size = new System.Drawing.Size(121, 23);
            this.cb_recomenda.TabIndex = 13;
            // 
            // btn_cadastrar_avaliacao
            // 
            this.btn_cadastrar_avaliacao.Location = new System.Drawing.Point(206, 465);
            this.btn_cadastrar_avaliacao.Name = "btn_cadastrar_avaliacao";
            this.btn_cadastrar_avaliacao.Size = new System.Drawing.Size(144, 92);
            this.btn_cadastrar_avaliacao.TabIndex = 14;
            this.btn_cadastrar_avaliacao.Text = "Save Avaliacao";
            this.btn_cadastrar_avaliacao.UseVisualStyleBackColor = true;
            this.btn_cadastrar_avaliacao.Click += new System.EventHandler(this.btn_cadastrar_avaliacao_Click);
            // 
            // avaliacao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 616);
            this.Controls.Add(this.btn_cadastrar_avaliacao);
            this.Controls.Add(this.cb_recomenda);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_avaliacao);
            this.Controls.Add(this.txt_motivo);
            this.Controls.Add(this.txt_tempo_contrato);
            this.Controls.Add(this.txt_id_user);
            this.Controls.Add(this.txt_id_imovel);
            this.Name = "avaliacao";
            this.Text = "avaliacao";
            this.Load += new System.EventHandler(this.avaliacao_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_id_imovel;
        private System.Windows.Forms.TextBox txt_id_user;
        private System.Windows.Forms.TextBox txt_tempo_contrato;
        private System.Windows.Forms.TextBox txt_motivo;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox txt_avaliacao;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cb_recomenda;
        private System.Windows.Forms.Button btn_cadastrar_avaliacao;
    }
}