﻿
namespace HouseDoor
{
    partial class avaliacoes_listar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listar_avaliacoes = new System.Windows.Forms.Button();
            this.txt_id_imovel = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgv_avaliacoes = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_avaliacoes)).BeginInit();
            this.SuspendLayout();
            // 
            // listar_avaliacoes
            // 
            this.listar_avaliacoes.Location = new System.Drawing.Point(30, 199);
            this.listar_avaliacoes.Name = "listar_avaliacoes";
            this.listar_avaliacoes.Size = new System.Drawing.Size(291, 59);
            this.listar_avaliacoes.TabIndex = 0;
            this.listar_avaliacoes.Text = "Listar avaliações do Imovel X";
            this.listar_avaliacoes.UseVisualStyleBackColor = true;
            this.listar_avaliacoes.Click += new System.EventHandler(this.listar_avaliacoes_Click);
            // 
            // txt_id_imovel
            // 
            this.txt_id_imovel.Location = new System.Drawing.Point(134, 25);
            this.txt_id_imovel.Name = "txt_id_imovel";
            this.txt_id_imovel.Size = new System.Drawing.Size(169, 23);
            this.txt_id_imovel.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Id do imovel";
            // 
            // dgv_avaliacoes
            // 
            this.dgv_avaliacoes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_avaliacoes.Location = new System.Drawing.Point(404, 28);
            this.dgv_avaliacoes.Name = "dgv_avaliacoes";
            this.dgv_avaliacoes.RowTemplate.Height = 25;
            this.dgv_avaliacoes.Size = new System.Drawing.Size(358, 230);
            this.dgv_avaliacoes.TabIndex = 3;
            // 
            // avaliacoes_listar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgv_avaliacoes);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_id_imovel);
            this.Controls.Add(this.listar_avaliacoes);
            this.Name = "avaliacoes_listar";
            this.Text = "avaliacoes_listar";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_avaliacoes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button listar_avaliacoes;
        private System.Windows.Forms.TextBox txt_id_imovel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgv_avaliacoes;
    }
}