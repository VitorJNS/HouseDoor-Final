﻿
namespace HouseDoor
{
    partial class imovel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_logradouro = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_estado = new System.Windows.Forms.TextBox();
            this.txt_cidade = new System.Windows.Forms.TextBox();
            this.txt_bairro = new System.Windows.Forms.TextBox();
            this.txt_numero = new System.Windows.Forms.TextBox();
            this.txt_tamanho_imovel = new System.Windows.Forms.TextBox();
            this.txt_valor = new System.Windows.Forms.TextBox();
            this.txt_descricao = new System.Windows.Forms.TextBox();
            this.txt_condominio = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_cep = new System.Windows.Forms.TextBox();
            this.txt_nmr_quarto = new System.Windows.Forms.TextBox();
            this.txt_numero_banheiro = new System.Windows.Forms.TextBox();
            this.txt_vagas = new System.Windows.Forms.TextBox();
            this.txt_andar = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_iptu = new System.Windows.Forms.TextBox();
            this.txt_mobilia = new System.Windows.Forms.TextBox();
            this.vemmobilia = new System.Windows.Forms.Label();
            this.txt_save_imovel = new System.Windows.Forms.Button();
            this.txt_imagem_imovel = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_logradouro
            // 
            this.txt_logradouro.Location = new System.Drawing.Point(261, 22);
            this.txt_logradouro.Name = "txt_logradouro";
            this.txt_logradouro.Size = new System.Drawing.Size(175, 23);
            this.txt_logradouro.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(195, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "logradouro";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(217, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "numero";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(217, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "cidade";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(217, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "bairro";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(217, 146);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "estado";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 0;
            // 
            // txt_estado
            // 
            this.txt_estado.Location = new System.Drawing.Point(261, 150);
            this.txt_estado.Name = "txt_estado";
            this.txt_estado.Size = new System.Drawing.Size(175, 23);
            this.txt_estado.TabIndex = 9;
            // 
            // txt_cidade
            // 
            this.txt_cidade.Location = new System.Drawing.Point(261, 121);
            this.txt_cidade.Name = "txt_cidade";
            this.txt_cidade.Size = new System.Drawing.Size(175, 23);
            this.txt_cidade.TabIndex = 10;
            // 
            // txt_bairro
            // 
            this.txt_bairro.Location = new System.Drawing.Point(261, 91);
            this.txt_bairro.Name = "txt_bairro";
            this.txt_bairro.Size = new System.Drawing.Size(175, 23);
            this.txt_bairro.TabIndex = 11;
            // 
            // txt_numero
            // 
            this.txt_numero.Location = new System.Drawing.Point(261, 61);
            this.txt_numero.Name = "txt_numero";
            this.txt_numero.Size = new System.Drawing.Size(175, 23);
            this.txt_numero.TabIndex = 12;
            // 
            // txt_tamanho_imovel
            // 
            this.txt_tamanho_imovel.Location = new System.Drawing.Point(261, 218);
            this.txt_tamanho_imovel.Name = "txt_tamanho_imovel";
            this.txt_tamanho_imovel.Size = new System.Drawing.Size(175, 23);
            this.txt_tamanho_imovel.TabIndex = 22;
            // 
            // txt_valor
            // 
            this.txt_valor.Location = new System.Drawing.Point(261, 248);
            this.txt_valor.Name = "txt_valor";
            this.txt_valor.Size = new System.Drawing.Size(175, 23);
            this.txt_valor.TabIndex = 21;
            // 
            // txt_descricao
            // 
            this.txt_descricao.Location = new System.Drawing.Point(261, 278);
            this.txt_descricao.Name = "txt_descricao";
            this.txt_descricao.Size = new System.Drawing.Size(175, 23);
            this.txt_descricao.TabIndex = 20;
            // 
            // txt_condominio
            // 
            this.txt_condominio.Location = new System.Drawing.Point(261, 307);
            this.txt_condominio.Name = "txt_condominio";
            this.txt_condominio.Size = new System.Drawing.Size(175, 23);
            this.txt_condominio.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(178, 315);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 15);
            this.label7.TabIndex = 18;
            this.label7.Text = "condominio";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(217, 248);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 15);
            this.label8.TabIndex = 17;
            this.label8.Text = "valor";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(193, 278);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 15);
            this.label9.TabIndex = 16;
            this.label9.Text = "descricao";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(159, 218);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 15);
            this.label10.TabIndex = 15;
            this.label10.Text = "tamanho_imovel";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(217, 187);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(26, 15);
            this.label11.TabIndex = 14;
            this.label11.Text = "cep";
            // 
            // txt_cep
            // 
            this.txt_cep.Location = new System.Drawing.Point(261, 179);
            this.txt_cep.Name = "txt_cep";
            this.txt_cep.Size = new System.Drawing.Size(175, 23);
            this.txt_cep.TabIndex = 13;
            // 
            // txt_nmr_quarto
            // 
            this.txt_nmr_quarto.Location = new System.Drawing.Point(261, 375);
            this.txt_nmr_quarto.Name = "txt_nmr_quarto";
            this.txt_nmr_quarto.Size = new System.Drawing.Size(175, 23);
            this.txt_nmr_quarto.TabIndex = 32;
            // 
            // txt_numero_banheiro
            // 
            this.txt_numero_banheiro.Location = new System.Drawing.Point(261, 405);
            this.txt_numero_banheiro.Name = "txt_numero_banheiro";
            this.txt_numero_banheiro.Size = new System.Drawing.Size(175, 23);
            this.txt_numero_banheiro.TabIndex = 31;
            // 
            // txt_vagas
            // 
            this.txt_vagas.Location = new System.Drawing.Point(261, 435);
            this.txt_vagas.Name = "txt_vagas";
            this.txt_vagas.Size = new System.Drawing.Size(175, 23);
            this.txt_vagas.TabIndex = 30;
            // 
            // txt_andar
            // 
            this.txt_andar.Location = new System.Drawing.Point(261, 464);
            this.txt_andar.Name = "txt_andar";
            this.txt_andar.Size = new System.Drawing.Size(175, 23);
            this.txt_andar.TabIndex = 29;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(217, 460);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 15);
            this.label12.TabIndex = 28;
            this.label12.Text = "andar";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(174, 408);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 15);
            this.label13.TabIndex = 27;
            this.label13.Text = "nmr_banheiro";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(217, 435);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 15);
            this.label14.TabIndex = 26;
            this.label14.Text = "vagas";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(186, 378);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(69, 15);
            this.label15.TabIndex = 25;
            this.label15.Text = "nmr_quarto";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(217, 344);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(28, 15);
            this.label16.TabIndex = 24;
            this.label16.Text = "iptu";
            // 
            // txt_iptu
            // 
            this.txt_iptu.Location = new System.Drawing.Point(261, 336);
            this.txt_iptu.Name = "txt_iptu";
            this.txt_iptu.Size = new System.Drawing.Size(175, 23);
            this.txt_iptu.TabIndex = 23;
            // 
            // txt_mobilia
            // 
            this.txt_mobilia.Location = new System.Drawing.Point(261, 493);
            this.txt_mobilia.Name = "txt_mobilia";
            this.txt_mobilia.Size = new System.Drawing.Size(175, 23);
            this.txt_mobilia.TabIndex = 34;
            // 
            // vemmobilia
            // 
            this.vemmobilia.AutoSize = true;
            this.vemmobilia.Location = new System.Drawing.Point(172, 496);
            this.vemmobilia.Name = "vemmobilia";
            this.vemmobilia.Size = new System.Drawing.Size(78, 15);
            this.vemmobilia.TabIndex = 33;
            this.vemmobilia.Text = "vem mobilia?";
            // 
            // txt_save_imovel
            // 
            this.txt_save_imovel.Location = new System.Drawing.Point(217, 584);
            this.txt_save_imovel.Name = "txt_save_imovel";
            this.txt_save_imovel.Size = new System.Drawing.Size(178, 44);
            this.txt_save_imovel.TabIndex = 35;
            this.txt_save_imovel.Text = "Salvar Imovel";
            this.txt_save_imovel.UseVisualStyleBackColor = true;
            this.txt_save_imovel.Click += new System.EventHandler(this.txt_save_imovel_Click);
            // 
            // txt_imagem_imovel
            // 
            this.txt_imagem_imovel.Location = new System.Drawing.Point(261, 531);
            this.txt_imagem_imovel.Name = "txt_imagem_imovel";
            this.txt_imagem_imovel.Size = new System.Drawing.Size(175, 23);
            this.txt_imagem_imovel.TabIndex = 36;
            this.txt_imagem_imovel.Click += new System.EventHandler(this.txt_imagem_imovel_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(159, 534);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 15);
            this.label17.TabIndex = 37;
            this.label17.Text = "Imagem Imóvel";
            // 
            // imovel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(894, 706);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txt_imagem_imovel);
            this.Controls.Add(this.txt_save_imovel);
            this.Controls.Add(this.txt_mobilia);
            this.Controls.Add(this.vemmobilia);
            this.Controls.Add(this.txt_nmr_quarto);
            this.Controls.Add(this.txt_numero_banheiro);
            this.Controls.Add(this.txt_vagas);
            this.Controls.Add(this.txt_andar);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txt_iptu);
            this.Controls.Add(this.txt_tamanho_imovel);
            this.Controls.Add(this.txt_valor);
            this.Controls.Add(this.txt_descricao);
            this.Controls.Add(this.txt_condominio);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt_cep);
            this.Controls.Add(this.txt_numero);
            this.Controls.Add(this.txt_bairro);
            this.Controls.Add(this.txt_cidade);
            this.Controls.Add(this.txt_estado);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_logradouro);
            this.Name = "imovel";
            this.Text = "imovel";
            this.Load += new System.EventHandler(this.imovel_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_logradouro;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_estado;
        private System.Windows.Forms.TextBox txt_cidade;
        private System.Windows.Forms.TextBox txt_bairro;
        private System.Windows.Forms.TextBox txt_numero;
        private System.Windows.Forms.TextBox txt_tamanho_imovel;
        private System.Windows.Forms.TextBox txt_valor;
        private System.Windows.Forms.TextBox txt_descricao;
        private System.Windows.Forms.TextBox txt_condominio;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_cep;
        private System.Windows.Forms.TextBox txt_nmr_quarto;
        private System.Windows.Forms.TextBox txt_numero_banheiro;
        private System.Windows.Forms.TextBox txt_vagas;
        private System.Windows.Forms.TextBox txt_andar;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txt_iptu;
        private System.Windows.Forms.TextBox txt_mobilia;
        private System.Windows.Forms.Label vemmobilia;
        private System.Windows.Forms.Button txt_save_imovel;
        private System.Windows.Forms.TextBox txt_imagem_imovel;
        private System.Windows.Forms.Label label17;
    }
}