﻿using System;

namespace HouseDoor.model
{
    public class Usuario
    {

        public string cpf { get; set; }
        public string email { get; set; }
        public string nome { get; set; }
        public string sobrenome { get; set; }
        public string senha { get; set; }
        public string telefone { get; set; }
        public string cep { get; set; }
        public string endereco { get; set; }
        public string bairro { get; set; }
        public string cidade { get; set; }
        public string uf { get; set; }

        public Usuario()
        {
        }

        public Usuario(string cpf, string email, string nome, string sobrenome, string senha, string telefone, string cep, string endereco, string bairro, string cidade, string uf)
        {
            this.cpf = cpf ?? throw new ArgumentNullException(nameof(cpf));
            this.email = email ?? throw new ArgumentNullException(nameof(email));
            this.nome = nome ?? throw new ArgumentNullException(nameof(nome));
            this.sobrenome = sobrenome ?? throw new ArgumentNullException(nameof(sobrenome));
            this.senha = senha ?? throw new ArgumentNullException(nameof(senha));
            this.telefone = telefone ?? throw new ArgumentNullException(nameof(telefone));
            this.cep = cep ?? throw new ArgumentNullException(nameof(cep));
            this.endereco = endereco ?? throw new ArgumentNullException(nameof(endereco));
            this.bairro = bairro ?? throw new ArgumentNullException(nameof(bairro));
            this.cidade = cidade ?? throw new ArgumentNullException(nameof(cidade));
            this.uf = uf ?? throw new ArgumentNullException(nameof(uf));
        }
            

    }
}
