﻿using System;

namespace HouseDoor.model
{
    class Imovel
    {
        public int id { get; set; }
        public string logradouro { get; set; }
        public string numero { get; set; }
        public string bairro { get; set; }
        public string cidade { get; set; }
        public string estado { get; set; }
        public string cep { get; set; }
        public double tamanho_imovel { get; set; }
        public double valor { get; set; }
        public string descricao { get; set; }
        public double condominio { get; set; }
        public double iptu { get; set; }
        public int quarto { get; set; }
        public int banheiro { get; set; }
        public int vagas { get; set; }
        public int andar { get; set; }
        public bool mobilia { get; set; }
        public string imagem { get; set; }

        public Imovel() { }

        public Imovel(int id, string logradouro, string numero, string bairro, string cidade,
            string estado, string cep, double tamanho_imovel, double valor, string descricao, double condominio,
            double iptu, int quarto, int banheiro, int vagas, int andar, bool mobilia, string imagem)
        {
            this.id = id;
            this.logradouro = logradouro ?? throw new ArgumentNullException(nameof(logradouro));
            this.numero = numero ?? throw new ArgumentNullException(nameof(numero));
            this.bairro = bairro ?? throw new ArgumentNullException(nameof(bairro));
            this.cidade = cidade ?? throw new ArgumentNullException(nameof(cidade));
            this.estado = estado ?? throw new ArgumentNullException(nameof(estado));
            this.cep = cep ?? throw new ArgumentNullException(nameof(cep));
            this.tamanho_imovel = tamanho_imovel;
            this.valor = valor;
            this.descricao = descricao ?? throw new ArgumentNullException(nameof(descricao));
            this.condominio = condominio;
            this.iptu = iptu;
            this.quarto = quarto;
            this.banheiro = banheiro;
            this.vagas = vagas;
            this.andar = andar;
            this.mobilia = mobilia;
            this.imagem = imagem;

        }
    }
}
