﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HouseDoor.model
{
    class Banco
    {
        static string connString = "server=localhost;database=banco;uid=root;pwd=1234;port=3306";


        public static void CreateUsuario(Usuario usuario)
        {

            using (MySqlConnection conn = new MySqlConnection())
            {
                conn.ConnectionString = connString;
                conn.Open();
                using (var command = conn.CreateCommand())
                {
                    command.CommandText = @"INSERT INTO usuario(cpf, email, nome, sobrenome, senha, telefone, cep, endereco, bairro, cidade, uf) value(
                            @cpf, @email, @nome, @sobrenome, @senha, @telefone, @cep, @endereco, @bairro, @cidade, @uf);";

                    command.Parameters.AddWithValue("@cpf", usuario.cpf);
                    command.Parameters.AddWithValue("@email", usuario.email);
                    command.Parameters.AddWithValue("@nome", usuario.nome);
                    command.Parameters.AddWithValue("@sobrenome", usuario.sobrenome);
                    command.Parameters.AddWithValue("@senha", usuario.senha);
                    command.Parameters.AddWithValue("@telefone", usuario.telefone);
                    command.Parameters.AddWithValue("@cep", usuario.cep);
                    command.Parameters.AddWithValue("@endereco", usuario.endereco);
                    command.Parameters.AddWithValue("@bairro", usuario.bairro);
                    command.Parameters.AddWithValue("@cidade", usuario.cidade);
                    command.Parameters.AddWithValue("@uf", usuario.uf);


                    int execution = command.ExecuteNonQuery();

                    if (execution > 0)
                    {
                        Console.WriteLine("Finished insert do user");

                    }
                    else
                    {
                        Console.WriteLine("Error to save");
                        new Exception("erro ao salvar user no banco");
                    }

                }
                conn.Close();
            }
        }


        public static void CreateImovel(Imovel imovel)
        {

            using (MySqlConnection conn = new MySqlConnection())
            {
                conn.ConnectionString = connString;
                conn.Open();
                using (var command = conn.CreateCommand())
                {
                    command.CommandText = @"INSERT INTO imovel (logradouro, numero, bairro, cidade, estado, cep, tamanho_imovel,
                        valor, descricao, condominio, iptu, quarto, banheiro, vagas, andar, mobilia, imagem)
                        value (@logradouro, @numero, @bairro, @cidade, @estado, @cep, @tamanho_imovel,
                        @valor, @descricao, @condominio, @iptu, @quarto, @banheiro, @vagas, @andar, @mobilia, @imagem);";

                    command.Parameters.AddWithValue("@logradouro", imovel.logradouro);
                    command.Parameters.AddWithValue("@numero", imovel.numero);
                    command.Parameters.AddWithValue("@bairro", imovel.bairro);
                    command.Parameters.AddWithValue("@cidade", imovel.cidade);
                    command.Parameters.AddWithValue("@estado", imovel.estado);
                    command.Parameters.AddWithValue("@cep", imovel.cep);
                    command.Parameters.AddWithValue("@tamanho_imovel", imovel.tamanho_imovel);
                    command.Parameters.AddWithValue("@valor", imovel.valor);
                    command.Parameters.AddWithValue("@descricao", imovel.descricao);
                    command.Parameters.AddWithValue("@condominio", imovel.condominio);
                    command.Parameters.AddWithValue("@iptu", imovel.iptu);
                    command.Parameters.AddWithValue("@quarto", imovel.quarto);
                    command.Parameters.AddWithValue("@banheiro", imovel.banheiro);
                    command.Parameters.AddWithValue("@vagas", imovel.vagas);
                    command.Parameters.AddWithValue("@andar", imovel.andar);
                    command.Parameters.AddWithValue("@mobilia", imovel.mobilia);
                    command.Parameters.AddWithValue("@imagem", imovel.imagem);


                    int execution = command.ExecuteNonQuery();

                    if (execution > 0)
                    {
                        MessageBox.Show("Finished insert imovel");

                    }
                    else
                    {
                        MessageBox.Show("Error to save");
                        new Exception("erro ao salvar imovel no banco");
                    }

                }
                conn.Close();
            }
        }


        public static void CreateAvaliacao(Avaliacao avaliacao)
        {

            using (MySqlConnection conn = new MySqlConnection())
            {
                conn.ConnectionString = connString;
                conn.Open();
                using (var command = conn.CreateCommand())
                {
                    command.CommandText = @"INSERT INTO avaliacao (id_imovel, id_user, tempo_contrato_meses, avaliacao, motivos, recomenda_imovel) values 
                        (@id_imovel, @id_user, @tempo_contrato_meses, @avaliacao, @motivos, @recomenda_imovel);";

                    command.Parameters.AddWithValue("@id_imovel", avaliacao.id_imovel);
                    command.Parameters.AddWithValue("@id_user", avaliacao.id_user);
                    command.Parameters.AddWithValue("@tempo_contrato_meses", avaliacao.tempo_contrato_meses);
                    command.Parameters.AddWithValue("@avaliacao", avaliacao.avaliacao);
                    command.Parameters.AddWithValue("@motivos", avaliacao.motivos);
                    command.Parameters.AddWithValue("@recomenda_imovel", avaliacao.recomenda_imovel);


                    int execution = command.ExecuteNonQuery();

                    if (execution > 0)
                    {
                        MessageBox.Show("Finished insert imovel");

                    }
                    else
                    {
                        MessageBox.Show("Error to save");
                        new Exception("erro ao salvar imovel no banco");
                    }

                }
                conn.Close();
            }
        }

        public static List<Avaliacao> BuscaAvaliacaoPorImovel(int id_imovel)
        {

            using (MySqlConnection conn = new MySqlConnection())
            {
                List<Avaliacao> avaliacoes = new List<Avaliacao>();

                conn.ConnectionString = connString;
                conn.Open();
                using (var command = conn.CreateCommand())
                {
                    command.CommandText = @" select * from avaliacao where id_imovel = @id_imovel;";

                    command.Parameters.AddWithValue("@id_imovel", id_imovel);

                    MySqlDataReader dataReader = command.ExecuteReader();


                    while (dataReader.Read())
                    {
                        Avaliacao avaliacao = new Avaliacao();
                        avaliacao.data_criacao = Convert.ToDateTime(dataReader["data_criacao"].ToString());
                        avaliacao.id_imovel = int.Parse(dataReader["id_imovel"].ToString());
                        avaliacao.id_user = dataReader["id_user"].ToString();
                        avaliacao.tempo_contrato_meses = int.Parse(dataReader["tempo_contrato_meses"].ToString());
                        avaliacao.avaliacao = int.Parse(dataReader["avaliacao"].ToString());
                        avaliacao.motivos = dataReader["motivos"].ToString();

                        avaliacao.recomenda_imovel = bool.Parse(dataReader["recomenda_imovel"].ToString());

                        avaliacoes.Add(avaliacao);
                    }

                }
                conn.Close();
                return avaliacoes;
            }
        }

        public static List<Imovel> BuscaImovelPorLogradouro(string logradouro)
        {

            using (MySqlConnection conn = new MySqlConnection())
            {
                List<Imovel> imoveis = new List<Imovel>();

                conn.ConnectionString = connString;
                conn.Open();
                using (var command = conn.CreateCommand())
                {
                    command.CommandText = @"select * from imovel where UPPER(logradouro) like CONCAT('%', @logradouro, '%');";

                    command.Parameters.AddWithValue("@logradouro", logradouro);

                    MySqlDataReader dataReader = command.ExecuteReader();

                    while (dataReader.Read())
                    {
                        Imovel imovel = new Imovel();
                        imovel.id = int.Parse(dataReader["id"].ToString());
                        imovel.logradouro = dataReader["logradouro"].ToString();
                        imovel.numero = dataReader["numero"].ToString();
                        imovel.bairro = dataReader["bairro"].ToString();
                        imovel.cidade = dataReader["cidade"].ToString();
                        imovel.estado = dataReader["estado"].ToString();
                        imovel.cep = dataReader["cep"].ToString();
                        imovel.tamanho_imovel = double.Parse(dataReader["tamanho_imovel"].ToString());
                        imovel.valor = double.Parse(dataReader["valor"].ToString());
                        imovel.descricao = dataReader["descricao"].ToString();
                        imovel.condominio = double.Parse(dataReader["condominio"].ToString());
                        imovel.iptu = double.Parse(dataReader["iptu"].ToString());
                        imovel.quarto = int.Parse(dataReader["quarto"].ToString());
                        imovel.banheiro = int.Parse(dataReader["banheiro"].ToString());
                        imovel.vagas = int.Parse(dataReader["vagas"].ToString());
                        imovel.andar = int.Parse(dataReader["andar"].ToString());
                        imovel.mobilia = bool.Parse(dataReader["mobilia"].ToString());
                        imovel.imagem = dataReader["imagem"].ToString();

                        imoveis.Add(imovel);
                    }

                }
                conn.Close();
                return imoveis;
            }
        }



            public static bool Login(string cpf, string senha)
            {

                using (MySqlConnection conn = new MySqlConnection())
                {
                    List<Imovel> imoveis = new List<Imovel>();

                    conn.ConnectionString = connString;
                    conn.Open();
                    using (var command = conn.CreateCommand())
                    {
                        command.CommandText = @"select * from imovel where cpf = @cpf and senha = @senha;";

                        command.Parameters.AddWithValue("@cpf", cpf);
                        command.Parameters.AddWithValue("@senha", senha);


                        MySqlDataReader dataReader = command.ExecuteReader();

                        while (dataReader.Read())
                        {
                          conn.Close();

                          return true;
                        }

                    }
                    conn.Close();
                    return false;
                }
            }
    }
}
