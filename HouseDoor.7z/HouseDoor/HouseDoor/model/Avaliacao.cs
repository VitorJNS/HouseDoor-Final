﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseDoor.model
{
    class Avaliacao
    {
        public int id { get; set; }
        public DateTime data_criacao { get; set; }
        public int id_imovel { get; set; }
        public string id_user { get; set; }
        public int tempo_contrato_meses { get; set; }
        public int avaliacao { get; set; }
        public string motivos { get; set; }
        public bool recomenda_imovel { get; set; }

        public Avaliacao() { }

        public Avaliacao(int id_imovel, string id_user, int tempo_contrato_meses,
            int avaliacao, string motivos, bool recomenda_imovel)
        {
            this.id_imovel = id_imovel;
            this.id_user = id_user ?? throw new ArgumentNullException(nameof(id_user));
            this.tempo_contrato_meses = tempo_contrato_meses;
            this.avaliacao = avaliacao;
            this.motivos = motivos ?? throw new ArgumentNullException(nameof(motivos));
            this.recomenda_imovel = recomenda_imovel;
        }
    }
}
